# Mypackage
Read the docstring